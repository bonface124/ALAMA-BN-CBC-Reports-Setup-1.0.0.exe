Get ALAMA-BN-CBC-Reports-Setup-1.0.0.exe (free, no software to install)
1. Sign in at github.com and create a new empty repository.
2. Upload ALL the files in this folder, including the hidden .github folder
   (drag the folder contents into "Add file > Upload files").
3. Open the Actions tab, choose "Build Windows Setup", and wait about 3 minutes.
4. Open the finished run and download the artifact "ALAMA-BN-CBC-Reports-Setup".
   Inside is the Setup .exe with the BN Alama logo as its icon.
Windows SmartScreen may say "unknown publisher" the first time: More info > Run anyway.
