const {app,BrowserWindow,Menu}=require('electron');const path=require('path');
function win(){const w=new BrowserWindow({width:1366,height:820,icon:path.join(__dirname,'icon.ico'),title:'ALAMA BN CBC reports',autoHideMenuBar:true,webPreferences:{contextIsolation:true}});Menu.setApplicationMenu(null);w.maximize();w.loadFile('index.html');}
app.whenReady().then(win);app.on('window-all-closed',()=>app.quit());
